#!/bin/bash

echo ""
echo "================================================"
echo "  PokéCollectr — One-Click Installer (Mac/Linux)"
echo "================================================"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo " [ERROR] Node.js is not installed."
    echo ""
    echo " Install it from: https://nodejs.org"
    echo " Then run this script again."
    echo ""
    exit 1
fi

echo " [OK] Node.js found: $(node --version)"
echo ""

# Install dependencies
echo " [1/3] Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo " [ERROR] npm install failed."
    exit 1
fi

echo ""
echo " [2/3] Finding your local IP..."

# Detect OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "localhost")
else
    IP=$(hostname -I | awk '{print $1}')
fi

echo ""
echo "================================================"
echo "  [3/3] Starting PokéCollectr..."
echo "================================================"
echo ""
echo "  Open on your phone:"
echo ""
echo "    http://$IP:5173"
echo ""
echo "  Or on this computer:"
echo ""
echo "    http://localhost:5173"
echo ""
echo "  Press Ctrl+C to stop."
echo "================================================"
echo ""

npm run dev
