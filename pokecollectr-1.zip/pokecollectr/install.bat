@echo off
title PokéCollectr Installer
color 0B
echo.
echo  ================================================
echo   PokéCollectr - One-Click Installer (Windows)
echo  ================================================
echo.

:: Check Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js is not installed.
    echo.
    echo  Please install it from: https://nodejs.org
    echo  Then run this script again.
    echo.
    pause
    exit /b 1
)

echo  [OK] Node.js found: 
node --version
echo.

:: Install dependencies
echo  [1/3] Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo  [ERROR] npm install failed.
    pause
    exit /b 1
)

echo.
echo  [2/3] Finding your local IP address...
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address"') do (
    set IP=%%a
    goto :found
)
:found
set IP=%IP:~1%

echo.
echo  ================================================
echo   [3/3] Starting PokéCollectr...
echo  ================================================
echo.
echo   Open on your phone:
echo.
echo     http://%IP%:5173
echo.
echo   Or on this PC:
echo.
echo     http://localhost:5173
echo.
echo   Press Ctrl+C to stop the server.
echo  ================================================
echo.

call npm run dev
pause
