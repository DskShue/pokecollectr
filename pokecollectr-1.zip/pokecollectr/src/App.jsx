import { useState, useRef, useCallback, useEffect, useMemo } from "react";

// ─── Pokemon TCG API ──────────────────────────────────────────────────────────
const TCG = "https://api.pokemontcg.io/v2";
async function tcgSearch(query) {
  const r = await fetch(`${TCG}/cards?q=name:"${encodeURIComponent(query)}"&pageSize=20&orderBy=-set.releaseDate`);
  const d = await r.json();
  return d.data || [];
}

// ─── Claude Vision ────────────────────────────────────────────────────────────
async function aiScanCard(b64) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: "image/jpeg", data: b64 } },
          { type: "text", text: `You are a Pokémon TCG expert. Identify this card image precisely. Respond ONLY with raw JSON (no markdown fences, no preamble):\n{"name":"Pokémon name","set":"Set name","number":"e.g. 4/102","rarity":"e.g. Holo Rare","type":"e.g. Fire","hp":null,"condition":"Mint|Near Mint|Lightly Played|Moderately Played|Heavily Played","confidence":"high|medium|low","notes":"any notes"}` }
        ]
      }]
    })
  });
  const d = await r.json();
  const txt = (d.content || []).map(b => b.text || "").join("").replace(/```json|```/g, "").trim();
  try { return JSON.parse(txt); } catch { return { name: null, confidence: "low", notes: "Parse failed" }; }
}

// ─── Storage ──────────────────────────────────────────────────────────────────
const KEY = "pokecollectr_v2";
const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; } };
const save = (c) => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch {} };

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmtUSD = (v) => v != null ? `$${parseFloat(v).toFixed(2)}` : "—";
const fmtEUR = (v) => v != null ? `€${parseFloat(v).toFixed(2)}` : "—";
const cardVal = (c) => {
  const p = c?.tcgplayer?.prices;
  return parseFloat(p?.holofoil?.market || p?.normal?.market || p?.reverseHolofoil?.market || p?.["1stEditionHolofoil"]?.market || 0);
};
const RARITY_COLORS = {
  "Common": "#94a3b8", "Uncommon": "#34d399", "Rare": "#fbbf24",
  "Holo Rare": "#60a5fa", "Rare Holo": "#60a5fa",
  "Ultra Rare": "#a78bfa", "Secret Rare": "#f472b6",
  "Illustration Rare": "#fb923c", "Special Illustration Rare": "#f43f5e",
  "Hyper Rare": "#ffffff",
};
const rc = (r) => RARITY_COLORS[r] || "#64748b";
const CONDITIONS = ["Mint", "Near Mint", "Lightly Played", "Moderately Played", "Heavily Played"];
const COND_MULT = { "Mint": 1.2, "Near Mint": 1.0, "Lightly Played": 0.85, "Moderately Played": 0.65, "Heavily Played": 0.4 };

// ─── Sub-components ───────────────────────────────────────────────────────────
function PriceTable({ prices }) {
  if (!prices) return <div style={{ color: "#475569", fontSize: 12 }}>No price data available</div>;
  const rows = [
    ["Normal", prices.normal], ["Holofoil", prices.holofoil],
    ["Reverse Holo", prices.reverseHolofoil], ["1st Ed. Holo", prices["1stEditionHolofoil"]],
    ["1st Ed. Normal", prices["1stEditionNormal"]],
  ].filter(([, p]) => p);
  if (!rows.length) return <div style={{ color: "#475569", fontSize: 12 }}>No price data available</div>;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      {rows.map(([label, p]) => (
        <div key={label} style={{ display: "grid", gridTemplateColumns: "110px 1fr 1fr 1fr", gap: 4, alignItems: "center", background: "#070f1e", borderRadius: 7, padding: "5px 10px", fontSize: 12 }}>
          <span style={{ color: "#64748b" }}>{label}</span>
          <span style={{ color: "#34d399", fontWeight: 700 }}>{fmtUSD(p.market)}</span>
          <span style={{ color: "#475569" }}>L {fmtUSD(p.low)}</span>
          <span style={{ color: "#475569" }}>H {fmtUSD(p.high)}</span>
        </div>
      ))}
    </div>
  );
}

function Tag({ label, color }) {
  return (
    <span style={{ display: "inline-block", background: color + "1a", color, border: `1px solid ${color}44`, borderRadius: 6, padding: "2px 9px", fontSize: 11, fontWeight: 700, letterSpacing: 0.3 }}>
      {label}
    </span>
  );
}

function Spinner() {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, padding: "40px 0" }}>
      <div style={{ width: 44, height: 44, border: "3px solid #0f172a", borderTop: "3px solid #60a5fa", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("scan");
  const [collection, setCollection] = useState(load);

  const [scanImg, setScanImg] = useState(null);
  const [scanAI, setScanAI] = useState(null);
  const [scanLoading, setScanLoading] = useState(false);
  const [scanErr, setScanErr] = useState(null);
  const [tcgMatches, setTcgMatches] = useState([]);
  const [selMatch, setSelMatch] = useState(null);
  const [addFlash, setAddFlash] = useState(false);
  const [overrideCondition, setOverrideCondition] = useState(null);
  const [dragging, setDragging] = useState(false);

  const [colFilter, setColFilter] = useState("");
  const [colSort, setColSort] = useState("newest");
  const [viewEntry, setViewEntry] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const [searchQ, setSearchQ] = useState("");
  const [searchRes, setSearchRes] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchDone, setSearchDone] = useState(false);
  const [previewCard, setPreviewCard] = useState(null);

  const fileRef = useRef();
  const camRef = useRef();

  const totalValue = useMemo(() => collection.reduce((s, e) => s + cardVal(e.tcgCard) * (COND_MULT[e.condition] || 1), 0), [collection]);
  const uniqueSets = useMemo(() => new Set(collection.map(e => e.tcgCard?.set?.id).filter(Boolean)).size, [collection]);
  const uniquePokemon = useMemo(() => new Set(collection.map(e => e.tcgCard?.name || e.aiName).filter(Boolean)).size, [collection]);

  const filteredCol = useMemo(() => {
    const q = colFilter.toLowerCase();
    return collection
      .filter(e => !q || (e.tcgCard?.name || e.aiName || "").toLowerCase().includes(q) || (e.tcgCard?.set?.name || "").toLowerCase().includes(q))
      .sort((a, b) => {
        if (colSort === "newest") return b.addedAt - a.addedAt;
        if (colSort === "oldest") return a.addedAt - b.addedAt;
        if (colSort === "name") return (a.tcgCard?.name || a.aiName || "").localeCompare(b.tcgCard?.name || b.aiName || "");
        if (colSort === "value") return (cardVal(b.tcgCard) * (COND_MULT[b.condition] || 1)) - (cardVal(a.tcgCard) * (COND_MULT[a.condition] || 1));
        if (colSort === "rarity") return (b.tcgCard?.rarity || "").localeCompare(a.tcgCard?.rarity || "");
        return 0;
      });
  }, [collection, colFilter, colSort]);

  const processFile = useCallback(async (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    setScanErr(null); setScanAI(null); setTcgMatches([]); setSelMatch(null); setAddFlash(false); setOverrideCondition(null);
    const reader = new FileReader();
    reader.onload = async (e) => {
      setScanImg(e.target.result);
      setScanLoading(true);
      try {
        const b64 = e.target.result.split(",")[1];
        const ai = await aiScanCard(b64);
        setScanAI(ai);
        if (ai.name) {
          const matches = await tcgSearch(ai.name);
          setTcgMatches(matches);
          if (matches.length) setSelMatch(matches[0]);
        }
      } catch (err) { setScanErr(err.message); }
      finally { setScanLoading(false); }
    };
    reader.readAsDataURL(file);
  }, []);

  const addToCollection = useCallback(() => {
    const condition = overrideCondition || scanAI?.condition || "Near Mint";
    const entry = { id: crypto.randomUUID(), addedAt: Date.now(), scanImg, aiName: scanAI?.name, aiSet: scanAI?.set, condition, tcgCard: selMatch || null };
    const updated = [entry, ...collection];
    setCollection(updated); save(updated);
    setAddFlash(true); setTimeout(() => setAddFlash(false), 2200);
  }, [scanImg, scanAI, selMatch, overrideCondition, collection]);

  const removeEntry = useCallback((id) => {
    const updated = collection.filter(e => e.id !== id);
    setCollection(updated); save(updated); setViewEntry(null); setDeleteConfirm(null);
  }, [collection]);

  const updateCondition = useCallback((id, condition) => {
    const updated = collection.map(e => e.id === id ? { ...e, condition } : e);
    setCollection(updated); save(updated);
    setViewEntry(prev => prev?.id === id ? { ...prev, condition } : prev);
  }, [collection]);

  const doSearch = useCallback(async () => {
    if (!searchQ.trim()) return;
    setSearchLoading(true); setSearchDone(false); setSearchRes([]);
    const res = await tcgSearch(searchQ);
    setSearchRes(res); setSearchLoading(false); setSearchDone(true);
  }, [searchQ]);

  const addSearchCard = useCallback((card) => {
    const entry = { id: crypto.randomUUID(), addedAt: Date.now(), scanImg: null, aiName: card.name, condition: "Near Mint", tcgCard: card };
    const updated = [entry, ...collection];
    setCollection(updated); save(updated);
  }, [collection]);

  const inCollection = useCallback((cardId) => collection.some(e => e.tcgCard?.id === cardId), [collection]);

  const C = { bg: "#04091a", surface: "#080f1f", border: "#0f2040", accent: "#3b82f6", green: "#34d399", purple: "#a78bfa", pink: "#f472b6", yellow: "#fbbf24", text: "#e2e8f0", muted: "#64748b", dim: "#1e3a5f" };
  const glassCard = { background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: 20 };

  return (
    <div style={{ minHeight: "100vh", minHeight: "100dvh", background: C.bg, fontFamily: "'DM Mono', 'Courier New', monospace", color: C.text, display: "flex", flexDirection: "column" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Bebas+Neue&display=swap');
        * { box-sizing: border-box; } body { margin: 0; background: #04091a; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
        .anim { animation: fadeIn 0.25s ease; }
        .card-thumb { transition: transform 0.18s, border-color 0.18s, box-shadow 0.18s; cursor: pointer; }
        .card-thumb:hover { transform: translateY(-3px) scale(1.03); border-color: #3b82f6 !important; box-shadow: 0 8px 24px #3b82f620; }
        .match-chip { transition: all 0.15s; cursor: pointer; }
        .match-chip:hover { border-color: #3b82f6 !important; }
        .match-chip.sel { border-color: #3b82f6 !important; background: #0c1f3a !important; box-shadow: 0 0 0 2px #3b82f640; }
        .btn { transition: opacity 0.15s, transform 0.1s; cursor: pointer; }
        .btn:hover { opacity: 0.88; } .btn:active { transform: scale(0.97); }
        .drop-zone { transition: border-color 0.2s, background 0.2s; }
        .drop-zone.drag { border-color: #3b82f6 !important; background: #0c1f3a !important; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: #04091a; }
        ::-webkit-scrollbar-thumb { background: #0f2040; border-radius: 3px; }
        input, select { outline: none; } input::placeholder { color: #334155; }
        .price-shine { background: linear-gradient(90deg,#34d399,#60a5fa,#34d399); background-size:200% 100%; animation: shimmer 2.5s linear infinite; -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
      `}</style>

      {/* HEADER */}
      <div style={{ background: `linear-gradient(180deg,#060d1e 0%,#04091a 100%)`, borderBottom: `1px solid ${C.border}`, padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 30, height: 30, borderRadius: "50%", background: "linear-gradient(135deg,#ef4444 50%,#fff 50%)", border: "2px solid #e2e8f0", boxShadow: "0 0 12px #ef444460", position: "relative" }}>
            <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 7, height: 7, borderRadius: "50%", background: "#fff", border: "2px solid #0f172a" }} />
          </div>
          <span style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 24, letterSpacing: 2, background: "linear-gradient(90deg,#60a5fa,#a78bfa,#f472b6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>PokéCollectr</span>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {[[collection.length, "cards", C.accent], [`$${totalValue.toFixed(0)}`, "value", C.green], [uniqueSets, "sets", C.purple]].map(([val, label, color]) => (
            <div key={label} style={{ textAlign: "center", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: "3px 8px", minWidth: 46 }}>
              <div style={{ color, fontFamily: "'Bebas Neue',sans-serif", fontSize: 14, letterSpacing: 1 }}>{val}</div>
              <div style={{ color: C.muted, fontSize: 9 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* NAV */}
      <div style={{ display: "flex", background: C.surface, borderBottom: `1px solid ${C.border}` }}>
        {[["scan","📷","SCAN"],["collection","📦","COLLECT"],["search","🔍","SEARCH"]].map(([id,icon,label]) => (
          <button key={id} className="btn" onClick={() => setTab(id)}
            style={{ flex:1, padding:"13px 4px", border:"none", background:"none", fontFamily:"inherit", fontSize:11, fontWeight:500, letterSpacing:1, cursor:"pointer", color:tab===id?C.accent:C.muted, borderBottom:`2px solid ${tab===id?C.accent:"transparent"}` }}>
            {icon} {label}
          </button>
        ))}
      </div>

      {/* BODY */}
      <div style={{ flex:1, padding:"16px 14px", maxWidth:820, margin:"0 auto", width:"100%", paddingBottom:32 }}>

        {/* ══ SCAN ══ */}
        {tab === "scan" && (
          <div className="anim">
            <div style={{ marginBottom:12, fontSize:12, color:C.muted }}>Drop a photo or use your camera — AI identifies the card instantly.</div>
            <div className={`drop-zone${dragging?" drag":""}`}
              style={{ ...glassCard, border:`2px dashed ${dragging?C.accent:C.dim}`, textAlign:"center", cursor:"pointer", marginBottom:10, minHeight:160, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:8 }}
              onClick={() => fileRef.current?.click()}
              onDragOver={e=>{e.preventDefault();setDragging(true);}}
              onDragLeave={()=>setDragging(false)}
              onDrop={e=>{e.preventDefault();setDragging(false);processFile(e.dataTransfer.files[0]);}}>
              {scanImg
                ? <img src={scanImg} alt="card" style={{ maxHeight:220, maxWidth:"100%", borderRadius:10, objectFit:"contain" }} />
                : <><div style={{fontSize:40}}>🃏</div><div style={{color:C.muted,fontSize:13}}>Drop card photo here</div><div style={{color:"#334155",fontSize:11}}>or tap to choose</div></>}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>processFile(e.target.files[0])} />
            <input ref={camRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>processFile(e.target.files[0])} />
            <div style={{ display:"flex", gap:8, marginBottom:14 }}>
              <button className="btn" style={{ flex:1, background:"#1e3a5f", border:"none", borderRadius:10, padding:"11px 0", color:C.text, fontFamily:"inherit", fontSize:13 }} onClick={()=>fileRef.current?.click()}>📁 File</button>
              <button className="btn" style={{ flex:1, background:"#1e3a5f", border:"none", borderRadius:10, padding:"11px 0", color:C.text, fontFamily:"inherit", fontSize:13 }} onClick={()=>camRef.current?.click()}>📷 Camera</button>
              {scanImg && <button className="btn" style={{ background:"#2d1515", border:`1px solid #7f1d1d`, borderRadius:10, padding:"11px 14px", color:"#f87171", fontFamily:"inherit", fontSize:13 }} onClick={()=>{setScanImg(null);setScanAI(null);setTcgMatches([]);setSelMatch(null);setScanErr(null);}}>✕</button>}
            </div>

            {scanLoading && <div style={{...glassCard,textAlign:"center"}}><Spinner /><div style={{color:C.accent,fontSize:13}}>AI scanning…</div><div style={{color:C.muted,fontSize:11,marginTop:4}}>Identifying + fetching live prices</div></div>}
            {scanErr && <div style={{...glassCard,border:`1px solid #7f1d1d`,color:"#f87171",fontSize:13,marginBottom:12}}>⚠ {scanErr}</div>}

            {scanAI && !scanLoading && (
              <div style={{...glassCard,marginBottom:12}} className="anim">
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                  <div>
                    <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:22,letterSpacing:1}}>{scanAI.name||"Unknown"}</div>
                    {scanAI.set && <div style={{color:C.muted,fontSize:12}}>{scanAI.set}{scanAI.number?` · ${scanAI.number}`:""}</div>}
                  </div>
                  <Tag label={`${scanAI.confidence||"?"} conf.`} color={scanAI.confidence==="high"?C.green:scanAI.confidence==="medium"?C.yellow:"#ef4444"} />
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:10}}>
                  {scanAI.rarity && <Tag label={scanAI.rarity} color={rc(scanAI.rarity)} />}
                  {scanAI.type && <Tag label={scanAI.type} color="#fb923c" />}
                  {scanAI.hp && <Tag label={`HP ${scanAI.hp}`} color={C.pink} />}
                </div>
                <div style={{color:C.muted,fontSize:11,marginBottom:6}}>CONDITION</div>
                <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                  {CONDITIONS.map(c => {
                    const active = (overrideCondition||scanAI.condition)===c;
                    return <button key={c} className="btn" onClick={()=>setOverrideCondition(c)}
                      style={{padding:"4px 8px",borderRadius:8,border:`1px solid ${active?C.accent:C.border}`,background:active?"#0c1f3a":"transparent",color:active?C.accent:C.muted,fontSize:10,fontFamily:"inherit"}}>{c}</button>;
                  })}
                </div>
                {scanAI.notes && <div style={{marginTop:10,color:C.muted,fontSize:12}}>{scanAI.notes}</div>}
              </div>
            )}

            {tcgMatches.length > 0 && !scanLoading && (
              <div style={{...glassCard,marginBottom:12}} className="anim">
                <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:10}}>TCG MATCHES — select best</div>
                <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:8}}>
                  {tcgMatches.map(m => (
                    <div key={m.id} className={`match-chip${selMatch?.id===m.id?" sel":""}`}
                      style={{minWidth:78,maxWidth:78,border:`1px solid ${C.border}`,borderRadius:10,overflow:"hidden",background:C.bg,flexShrink:0}}
                      onClick={()=>setSelMatch(m)}>
                      <img src={m.images?.small} alt={m.name} style={{width:"100%",display:"block"}} />
                      <div style={{padding:"2px 4px",fontSize:8,color:C.muted,lineHeight:1.3}}>{m.set?.name}</div>
                    </div>
                  ))}
                </div>
                {selMatch && (
                  <div style={{marginTop:14}} className="anim">
                    <div style={{display:"flex",gap:12,marginBottom:12}}>
                      <img src={selMatch.images?.large||selMatch.images?.small} alt="" style={{width:90,borderRadius:8,flexShrink:0}} />
                      <div>
                        <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:17,letterSpacing:1}}>{selMatch.name}</div>
                        <div style={{color:C.muted,fontSize:11,marginBottom:5}}>{selMatch.set?.name} · {selMatch.number}</div>
                        <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                          {selMatch.rarity && <Tag label={selMatch.rarity} color={rc(selMatch.rarity)} />}
                        </div>
                        <div style={{marginTop:5,fontSize:11,color:C.muted}}>
                          <div>Artist: {selMatch.artist||"—"}</div>
                          <div>Released: {selMatch.set?.releaseDate||"—"}</div>
                        </div>
                      </div>
                    </div>
                    <div style={{marginBottom:10}}>
                      <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:6}}>TCGPLAYER (USD)</div>
                      <PriceTable prices={selMatch.tcgplayer?.prices} />
                    </div>
                    {selMatch.cardmarket?.prices && (
                      <div style={{marginBottom:10}}>
                        <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:4}}>CARDMARKET (EUR)</div>
                        <div style={{display:"flex",gap:10,fontSize:12}}>
                          <span style={{color:C.green}}>Trend {fmtEUR(selMatch.cardmarket.prices.trendPrice)}</span>
                          <span style={{color:C.muted}}>Avg30 {fmtEUR(selMatch.cardmarket.prices.avg30)}</span>
                        </div>
                      </div>
                    )}
                    <div style={{background:C.bg,borderRadius:10,padding:12,border:`1px solid ${C.border}`,marginBottom:12}}>
                      <div style={{color:C.purple,fontSize:12,fontWeight:500,letterSpacing:1,marginBottom:6}}>⚡ TRADE INFO</div>
                      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"3px 12px",fontSize:11}}>
                        {[["Series",selMatch.set?.series],["Standard",selMatch.legalities?.standard],["Expanded",selMatch.legalities?.expanded],["Set Total",selMatch.set?.total],["HP",selMatch.hp],["Retreat",selMatch.retreatCost?.length]].map(([k,v])=>(
                          <div key={k}><span style={{color:C.muted}}>{k}: </span><span>{v||"—"}</span></div>
                        ))}
                      </div>
                      {selMatch.tcgplayer?.url && <a href={selMatch.tcgplayer.url} target="_blank" rel="noopener noreferrer" style={{display:"inline-block",marginTop:8,color:C.accent,fontSize:12}}>Buy on TCGPlayer →</a>}
                    </div>
                    <button className="btn" onClick={addToCollection}
                      style={{width:"100%",padding:"12px 0",border:"none",borderRadius:12,background:addFlash?C.green:C.accent,color:"#fff",fontFamily:"inherit",fontSize:14,fontWeight:500}}>
                      {addFlash?"✅ Added!":"➕ Add to Collection"}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ══ COLLECTION ══ */}
        {tab === "collection" && (
          <div className="anim">
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,marginBottom:14}}>
              {[["📦",collection.length,"Cards",C.accent],["💰",`$${totalValue.toFixed(0)}`,"Value",C.green],["🗂",uniqueSets,"Sets",C.purple],["⭐",uniquePokemon,"Unique",C.yellow]].map(([icon,val,label,color])=>(
                <div key={label} style={{...glassCard,padding:"8px 4px",textAlign:"center"}}>
                  <div style={{fontSize:14}}>{icon}</div>
                  <div style={{color,fontFamily:"'Bebas Neue',sans-serif",fontSize:16,letterSpacing:1}}>{val}</div>
                  <div style={{color:C.muted,fontSize:9}}>{label}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:8,marginBottom:12}}>
              <input style={{flex:1,background:C.surface,border:`1px solid ${C.border}`,borderRadius:10,padding:"9px 12px",color:C.text,fontSize:13,fontFamily:"inherit"}} placeholder="Filter…" value={colFilter} onChange={e=>setColFilter(e.target.value)} />
              <select style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:10,padding:"9px 8px",color:C.text,fontSize:12,fontFamily:"inherit"}} value={colSort} onChange={e=>setColSort(e.target.value)}>
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
                <option value="name">Name</option>
                <option value="value">Value</option>
                <option value="rarity">Rarity</option>
              </select>
            </div>
            {filteredCol.length === 0
              ? <div style={{...glassCard,textAlign:"center",padding:40,color:C.muted}}><div style={{fontSize:36}}>📭</div><div style={{marginTop:8}}>{collection.length===0?"No cards yet — scan one!":"No cards match filter"}</div></div>
              : <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))",gap:8}}>
                  {filteredCol.map(entry=>{
                    const img=entry.tcgCard?.images?.small||entry.scanImg;
                    const name=entry.tcgCard?.name||entry.aiName||"Unknown";
                    const val=cardVal(entry.tcgCard)*(COND_MULT[entry.condition]||1);
                    return (
                      <div key={entry.id} className="card-thumb" style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:12,overflow:"hidden"}} onClick={()=>setViewEntry(entry)}>
                        {img?<img src={img} alt={name} style={{width:"100%",display:"block",aspectRatio:"0.72",objectFit:"cover"}} />:<div style={{aspectRatio:"0.72",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>🃏</div>}
                        <div style={{padding:"5px 7px"}}>
                          <div style={{fontSize:11,fontWeight:500,color:C.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{name}</div>
                          <div style={{display:"flex",justifyContent:"space-between",marginTop:1}}>
                            {val>0?<span style={{fontSize:11,color:C.green}}>${val.toFixed(2)}</span>:<span style={{fontSize:11,color:C.muted}}>—</span>}
                            {entry.condition&&<span style={{fontSize:9,color:C.muted}}>{entry.condition.split(" ").map(w=>w[0]).join("")}</span>}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
            }
          </div>
        )}

        {/* ══ SEARCH ══ */}
        {tab === "search" && (
          <div className="anim">
            <div style={{marginBottom:12,fontSize:12,color:C.muted}}>Search any Pokémon card to view prices and add to collection.</div>
            <div style={{display:"flex",gap:8,marginBottom:14}}>
              <input style={{flex:1,background:C.surface,border:`1px solid ${C.border}`,borderRadius:10,padding:"10px 12px",color:C.text,fontSize:14,fontFamily:"inherit"}}
                placeholder="Charizard, Pikachu, Mewtwo…" value={searchQ} onChange={e=>setSearchQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doSearch()} />
              <button className="btn" style={{background:C.accent,border:"none",borderRadius:10,padding:"10px 16px",color:"#fff",fontFamily:"inherit",fontSize:13,fontWeight:500}} onClick={doSearch}>Go</button>
            </div>
            {searchLoading && <div style={{...glassCard,textAlign:"center"}}><Spinner /><div style={{color:C.accent,fontSize:13}}>Searching…</div></div>}
            {searchDone && searchRes.length===0 && !searchLoading && <div style={{...glassCard,textAlign:"center",color:C.muted,padding:32}}>No cards found for "{searchQ}"</div>}
            {searchRes.length>0 && (
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))",gap:8}}>
                {searchRes.map(card=>{
                  const val=cardVal(card);
                  const owned=inCollection(card.id);
                  return (
                    <div key={card.id} className="card-thumb" style={{background:C.surface,border:`1px solid ${owned?C.green:C.border}`,borderRadius:12,overflow:"hidden"}} onClick={()=>setPreviewCard(card)}>
                      <img src={card.images?.small} alt={card.name} style={{width:"100%",display:"block"}} />
                      <div style={{padding:"5px 7px"}}>
                        <div style={{fontSize:11,fontWeight:500,color:C.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{card.name}</div>
                        <div style={{fontSize:9,color:C.muted,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{card.set?.name}</div>
                        <div style={{display:"flex",justifyContent:"space-between",marginTop:1}}>
                          <span style={{fontSize:11,color:val?C.green:C.muted}}>{val?`$${val.toFixed(2)}`:"—"}</span>
                          {owned&&<span style={{fontSize:9,color:C.green}}>✓</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ══ COLLECTION MODAL ══ */}
      {viewEntry && (
        <div style={{position:"fixed",inset:0,background:"#000d",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:16}} onClick={()=>{setViewEntry(null);setDeleteConfirm(null);}}>
          <div style={{...glassCard,maxWidth:440,width:"100%",maxHeight:"90vh",overflowY:"auto",borderRadius:20}} className="anim" onClick={e=>e.stopPropagation()}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
              <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:20,letterSpacing:1}}>{viewEntry.tcgCard?.name||viewEntry.aiName||"Unknown"}</div>
              <button className="btn" style={{background:"none",border:"none",color:C.muted,fontSize:20}} onClick={()=>setViewEntry(null)}>✕</button>
            </div>
            <div style={{display:"flex",gap:12,marginBottom:14}}>
              {(viewEntry.tcgCard?.images?.large||viewEntry.scanImg) && <img src={viewEntry.tcgCard?.images?.large||viewEntry.scanImg} alt="" style={{width:120,borderRadius:10,flexShrink:0,objectFit:"contain",alignSelf:"flex-start"}} />}
              <div style={{flex:1,fontSize:12}}>
                {viewEntry.tcgCard&&<>
                  <div style={{color:C.muted}}>Set</div><div style={{marginBottom:3}}>{viewEntry.tcgCard.set?.name}</div>
                  <div style={{color:C.muted}}>Number</div><div style={{marginBottom:3}}>{viewEntry.tcgCard.number}</div>
                  <div style={{color:C.muted}}>Rarity</div><div style={{marginBottom:6}}><Tag label={viewEntry.tcgCard.rarity||"—"} color={rc(viewEntry.tcgCard.rarity)} /></div>
                  <div style={{color:C.muted}}>Artist</div><div style={{marginBottom:6}}>{viewEntry.tcgCard.artist||"—"}</div>
                </>}
                <div style={{color:C.muted}}>Added</div><div>{new Date(viewEntry.addedAt).toLocaleDateString()}</div>
              </div>
            </div>
            <div style={{marginBottom:12}}>
              <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:6}}>CONDITION</div>
              <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                {CONDITIONS.map(c=>{
                  const active=viewEntry.condition===c;
                  return <button key={c} className="btn" onClick={()=>updateCondition(viewEntry.id,c)}
                    style={{padding:"4px 8px",borderRadius:8,border:`1px solid ${active?C.accent:C.border}`,background:active?"#0c1f3a":"transparent",color:active?C.accent:C.muted,fontSize:10,fontFamily:"inherit"}}>{c}</button>;
                })}
              </div>
            </div>
            {viewEntry.tcgCard?.tcgplayer?.prices && (
              <div style={{marginBottom:12}}>
                <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:6}}>MARKET PRICES</div>
                <PriceTable prices={viewEntry.tcgCard.tcgplayer.prices} />
                <div style={{marginTop:6,fontSize:12}}>
                  <span style={{color:C.muted}}>Value at {viewEntry.condition}: </span>
                  <span className="price-shine" style={{fontWeight:700}}>${(cardVal(viewEntry.tcgCard)*(COND_MULT[viewEntry.condition]||1)).toFixed(2)}</span>
                </div>
              </div>
            )}
            {viewEntry.tcgCard?.tcgplayer?.url && <a href={viewEntry.tcgCard.tcgplayer.url} target="_blank" rel="noopener noreferrer" style={{display:"inline-block",color:C.accent,fontSize:12,marginBottom:12}}>View on TCGPlayer →</a>}
            {deleteConfirm
              ? <div style={{display:"flex",gap:8}}>
                  <button className="btn" style={{flex:1,padding:11,border:"none",borderRadius:10,background:"#7f1d1d",color:"#fca5a5",fontFamily:"inherit",fontSize:13}} onClick={()=>removeEntry(viewEntry.id)}>Yes, remove</button>
                  <button className="btn" style={{flex:1,padding:11,border:`1px solid ${C.border}`,borderRadius:10,background:"transparent",color:C.muted,fontFamily:"inherit",fontSize:13}} onClick={()=>setDeleteConfirm(null)}>Cancel</button>
                </div>
              : <button className="btn" style={{width:"100%",padding:11,border:`1px solid #7f1d1d`,borderRadius:10,background:"transparent",color:"#f87171",fontFamily:"inherit",fontSize:13}} onClick={()=>setDeleteConfirm(true)}>🗑 Remove from Collection</button>
            }
          </div>
        </div>
      )}

      {/* ══ SEARCH PREVIEW MODAL ══ */}
      {previewCard && (
        <div style={{position:"fixed",inset:0,background:"#000d",zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",padding:16}} onClick={()=>setPreviewCard(null)}>
          <div style={{...glassCard,maxWidth:420,width:"100%",maxHeight:"90vh",overflowY:"auto",borderRadius:20}} className="anim" onClick={e=>e.stopPropagation()}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:14}}>
              <div style={{fontFamily:"'Bebas Neue',sans-serif",fontSize:20,letterSpacing:1}}>{previewCard.name}</div>
              <button className="btn" style={{background:"none",border:"none",color:C.muted,fontSize:20}} onClick={()=>setPreviewCard(null)}>✕</button>
            </div>
            <div style={{display:"flex",gap:12,marginBottom:14}}>
              <img src={previewCard.images?.large||previewCard.images?.small} alt="" style={{width:120,borderRadius:10,flexShrink:0}} />
              <div style={{fontSize:12}}>
                <div style={{color:C.muted}}>Set</div><div style={{marginBottom:3}}>{previewCard.set?.name}</div>
                <div style={{color:C.muted}}>Number</div><div style={{marginBottom:3}}>{previewCard.number}</div>
                <div style={{color:C.muted}}>Rarity</div><div style={{marginBottom:5}}><Tag label={previewCard.rarity||"—"} color={rc(previewCard.rarity)} /></div>
                <div style={{color:C.muted}}>Artist</div><div style={{marginBottom:3}}>{previewCard.artist||"—"}</div>
                <div style={{color:C.muted}}>Released</div><div>{previewCard.set?.releaseDate||"—"}</div>
              </div>
            </div>
            <div style={{marginBottom:10}}>
              <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:6}}>TCGPLAYER PRICES</div>
              <PriceTable prices={previewCard.tcgplayer?.prices} />
            </div>
            {previewCard.cardmarket?.prices && (
              <div style={{marginBottom:12,fontSize:12}}>
                <div style={{color:C.muted,fontSize:11,letterSpacing:1,marginBottom:4}}>CARDMARKET (EUR)</div>
                <span style={{color:C.green}}>Trend {fmtEUR(previewCard.cardmarket.prices.trendPrice)}</span>
                <span style={{color:C.muted}}> · Avg30 {fmtEUR(previewCard.cardmarket.prices.avg30)}</span>
              </div>
            )}
            {previewCard.tcgplayer?.url && <a href={previewCard.tcgplayer.url} target="_blank" rel="noopener noreferrer" style={{display:"inline-block",color:C.accent,fontSize:12,marginBottom:12}}>View on TCGPlayer →</a>}
            <button className="btn"
              style={{width:"100%",padding:11,border:"none",borderRadius:10,background:inCollection(previewCard.id)?"#14532d":C.accent,color:"#fff",fontFamily:"inherit",fontSize:13,fontWeight:500}}
              onClick={()=>{if(!inCollection(previewCard.id)){addSearchCard(previewCard);}}}>
              {inCollection(previewCard.id)?"✅ In Collection":"➕ Add to Collection"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
