# PokéCollectr 📦

Your personal Pokémon TCG collection app — AI card scanning, live prices, trade info. No ads. No account. Unlimited use.

---

## Requirements

- [Node.js](https://nodejs.org) (v18 or newer)
- Your phone and PC on the **same Wi-Fi network**

---

## Install & Run

### Windows
Double-click **`install.bat`**

That's it. It installs dependencies, finds your IP, and prints the URL to open on your phone.

---

### Mac / Linux
```bash
chmod +x install.sh
./install.sh
```

---

### Manual (any OS)
```bash
npm install
npm run dev
```

Then open `http://YOUR-PC-IP:5173` on your phone.

---

## Add to Phone Home Screen (makes it feel like a real app)

**iPhone (Safari)**
1. Open the URL in Safari
2. Tap the Share button
3. Tap "Add to Home Screen"

**Android (Chrome)**
1. Open the URL in Chrome
2. Tap the 3-dot menu
3. Tap "Add to Home Screen"

---

## Features

- 📷 **AI Card Scan** — photo identifies card name, set, rarity, HP, condition
- 💰 **Live Prices** — TCGPlayer (USD) + Cardmarket (EUR)
- ⚡ **Trade Info** — legality, series, artist, release date, buy links
- 📦 **Collection** — grid view, filter, sort by name/value/rarity/date
- 🔍 **Search** — browse any Pokémon card from the full TCG database
- 💾 **Local Storage** — your collection is saved on your device, no account needed

---

## Stopping the server
Press `Ctrl+C` in the terminal window.
